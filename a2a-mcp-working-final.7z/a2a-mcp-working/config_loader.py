"""
Load agent and host bind settings from config.json.
Config file path: project root / config.json (or CONFIG_PATH env).
"""
import json
import os
from pathlib import Path
from typing import Any

# Project root: directory containing config.json
ROOT = Path(__file__).resolve().parent

_DEFAULT_CONFIG = {
    "agent": {"host": "0.0.0.0", "port": 8001},
    "mcp_agent": {"host": "0.0.0.0", "port": 8002, "registry_path": "mcp_registry"},
    "host": {"host": "0.0.0.0", "port": 8080},
}

_config: dict[str, Any] | None = None


def _load_config() -> dict[str, Any]:
    global _config
    if _config is not None:
        return _config
    path = os.environ.get("CONFIG_PATH") or str(ROOT / "config.json")
    try:
        with open(path, encoding="utf-8") as f:
            _config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        _config = _DEFAULT_CONFIG.copy()
    return _config


def get_config() -> dict[str, Any]:
    """Return full config dict (agent, mcp_agent, host sections)."""
    return _load_config()


def get_agent_host_port() -> tuple[str, int]:
    """Return (host, port) for the LangGraph Assistant agent server."""
    c = _load_config().get("agent", _DEFAULT_CONFIG["agent"])
    return (
        c.get("host", _DEFAULT_CONFIG["agent"]["host"]),
        int(c.get("port", _DEFAULT_CONFIG["agent"]["port"])),
    )


def get_mcp_agent_host_port() -> tuple[str, int]:
    """Return (host, port) for the MCP Tool Agent server."""
    c = _load_config().get("mcp_agent", _DEFAULT_CONFIG["mcp_agent"])
    return (
        c.get("host", _DEFAULT_CONFIG["mcp_agent"]["host"]),
        int(c.get("port", _DEFAULT_CONFIG["mcp_agent"]["port"])),
    )


def get_mcp_agent_registry_path() -> Path:
    """
    Return the MCP registry path for the MCP agent (its own MCP server config).
    Precedence: MCP_REGISTRY_PATH env > config mcp_agent.registry_path > default mcp_registry.
    Path can be a directory (containing server.json) or a server.json file; returned as Path.
    """
    env_path = os.environ.get("MCP_REGISTRY_PATH", "").strip()
    if env_path:
        p = Path(env_path)
        return p.resolve()
    c = _load_config().get("mcp_agent", _DEFAULT_CONFIG["mcp_agent"])
    raw = c.get("registry_path", _DEFAULT_CONFIG["mcp_agent"]["registry_path"])
    if not raw:
        return (ROOT / "mcp_registry").resolve()
    p = Path(raw)
    if not p.is_absolute():
        p = ROOT / p
    return p.resolve()


def get_host_host_port() -> tuple[str, int]:
    """Return (host, port) for the A2A Host server."""
    c = _load_config().get("host", _DEFAULT_CONFIG["host"])
    return (
        c.get("host", _DEFAULT_CONFIG["host"]["host"]),
        int(c.get("port", _DEFAULT_CONFIG["host"]["port"])),
    )
