"""
Simple LangGraph agent (no tools). Uses llm_model.get_llm() for provider-agnostic LLM.
"""
import sys
from pathlib import Path

# Project root for llm_model
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from langgraph.prebuilt import create_react_agent

from llm_model import get_llm


def _get_agent():
    model = get_llm()
    return create_react_agent(
        model=model,
        tools=[],  # No tools for simple agent
        prompt="You are a helpful assistant. Answer concisely.",
    )


_agent = None


def get_agent():
    global _agent
    if _agent is None:
        _agent = _get_agent()
    return _agent


async def run_agent(user_message: str) -> str:
    """Run the LangGraph agent and return the final text response."""
    agent = get_agent()
    result = await agent.ainvoke({"messages": [{"role": "user", "content": user_message}]})
    messages = result.get("messages", [])
    if not messages:
        return "No response generated."
    last = messages[-1]
    if hasattr(last, "content"):
        return (last.content or "").strip() or "No response generated."
    if isinstance(last, dict):
        return (last.get("content") or "").strip() or "No response generated."
    return str(last).strip() or "No response generated."
