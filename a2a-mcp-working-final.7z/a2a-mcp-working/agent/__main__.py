"""
Run the LangGraph A2A agent server (OpenAI).
Set OPENAI_API_KEY in env. Host/port from config.json (see config_loader).
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import uvicorn
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from dotenv import load_dotenv
load_dotenv()

from agent.agent_executor import LangGraphAgentExecutor
from config_loader import get_agent_host_port


def main(host: str | None = None, port: int | None = None):
    if not os.getenv("OPENAI_API_KEY"):
        raise ValueError("OPENAI_API_KEY environment variable is required")

    cfg_host, cfg_port = get_agent_host_port()
    host = host if host is not None else cfg_host
    port = port if port is not None else cfg_port

    skill = AgentSkill(
        id="general_assistant",
        name="General Assistant",
        description="Answers questions and assists with general tasks using OpenAI",
        tags=["assistant", "openai", "langgraph"],
        examples=["What is the capital of France?", "Explain recursion briefly"],
    )

    app_url = os.environ.get("AGENT_URL", f"http://{host}:{port}")
    agent_card = AgentCard(
        name="LangGraph Assistant",
        description="A simple LangGraph agent powered by OpenAI.",
        url=app_url,
        version="1.0.0",
        default_input_modes=["text"],
        default_output_modes=["text"],
        capabilities=AgentCapabilities(streaming=True),
        skills=[skill],
    )

    request_handler = DefaultRequestHandler(
        agent_executor=LangGraphAgentExecutor(),
        task_store=InMemoryTaskStore(),
    )

    app = A2AStarletteApplication(
        agent_card=agent_card,
        http_handler=request_handler,
    )

    uvicorn.run(app.build(), host=host, port=port)


if __name__ == "__main__":
    main()
