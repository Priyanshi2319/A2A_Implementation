# MCP-backed A2A agent (LangGraph + MCP tools)
