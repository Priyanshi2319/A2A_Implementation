"""
Load agent and host bind settings from config.json.
Config file path: project root / config.json (or CONFIG_PATH env).
"""
import json
import os
from pathlib import Path
from typing import Any

# Project root: directory containing config.json
ROOT = Path(__file__).resolve().parent

_DEFAULT_CONFIG = {
    "agent": {"host": "0.0.0.0", "port": 8001},
    "mcp_agent": {"host": "0.0.0.0", "port": 8002, "registry_path": "mcp_registry"},
    "dm_agent": {"host": "0.0.0.0", "port": 8003, "registry_path": "mcp_registry"},
    "am_agent": {"host": "0.0.0.0", "port": 8004, "registry_path": "mcp_registry"},
    "portfolio_agent": {"host": "0.0.0.0", "port": 8005, "registry_path": "mcp_registry"},
    "host": {"host": "0.0.0.0", "port": 8080},
}

_config: dict[str, Any] | None = None


def _load_config() -> dict[str, Any]:
    global _config
    if _config is not None:
        return _config
    path = os.environ.get("CONFIG_PATH") or str(ROOT / "config.json")
    try:
        with open(path, encoding="utf-8") as f:
            _config = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        _config = _DEFAULT_CONFIG.copy()
    return _config


def get_config() -> dict[str, Any]:
    """Return full config dict (agent, mcp_agent, host sections)."""
    return _load_config()


def get_agent_host_port(agent:str) -> tuple[str, int]:
    """Return (host, port) for the LangGraph Assistant agent server."""
    c = _load_config().get(agent, _DEFAULT_CONFIG["agent"])
    return (
        c.get("host", _DEFAULT_CONFIG["agent"]["host"]),
        int(c.get("port", _DEFAULT_CONFIG["agent"]["port"])),
    )


def get_mcp_agent_host_port(mcp_name:str) -> tuple[str, int]:
    """Return (host, port) for the MCP Tool Agent server."""
    c = _load_config().get(mcp_name, _DEFAULT_CONFIG["mcp_agent"])
    return (
        c.get("host", _DEFAULT_CONFIG["mcp_agent"]["host"]),
        int(c.get("port", _DEFAULT_CONFIG["mcp_agent"]["port"])),
    )


def get_mcp_agent_registry_path() -> Path:
    """
    Return the MCP registry path for the MCP agent (its own MCP server config).
    Precedence: MCP_REGISTRY_PATH env > config mcp_agent.registry_path > default mcp_registry.
    Path can be a directory (containing server.json) or a server.json file; returned as Path.
    """
    env_path = os.environ.get("MCP_REGISTRY_PATH", "").strip()
    if env_path:
        p = Path(env_path)
        return p.resolve()
    c = _load_config().get("mcp_agent", _DEFAULT_CONFIG["mcp_agent"])
    raw = c.get("registry_path", _DEFAULT_CONFIG["mcp_agent"]["registry_path"])
    if not raw:
        return (ROOT / "mcp_registry").resolve()
    p = Path(raw)
    if not p.is_absolute():
        p = ROOT / p
    return p.resolve()


def get_host_host_port() -> tuple[str, int]:
    """Return (host, port) for the A2A Host server."""
    c = _load_config().get("host", _DEFAULT_CONFIG["host"])
    return (
        c.get("host", _DEFAULT_CONFIG["host"]["host"]),
        int(c.get("port", _DEFAULT_CONFIG["host"]["port"])),
    )


def get_registry_path_for_agent(agent_key: str) -> Path:
    """
    Return the MCP registry path for a specific agent (e.g. dm_agent, am_agent, portfolio_agent).
    Reads from config.json under agent_key.registry_path; path is relative to project root.
    """
    c = _load_config().get(agent_key)
    if not c:
        if agent_key == "dm_agent":
            raw = _DEFAULT_CONFIG.get("dm_agent", {}).get("registry_path", "mcp_registry/dm/")
        elif agent_key == "am_agent":
            raw = _DEFAULT_CONFIG.get("am_agent", {}).get("registry_path", "mcp_registry/am/")
        elif agent_key == "portfolio_agent":
            raw = _DEFAULT_CONFIG.get("portfolio_agent", {}).get("registry_path", "mcp_registry/portfolio/")
        else:
            raw = "mcp_registry"
    else:
        raw = c.get("registry_path", "mcp_registry")
    p = Path(raw)
    if not p.is_absolute():
        p = ROOT / p
    return p.resolve()


def get_agent_registry_path() -> Path:
    """
    Return path to agent_registry.json for the host. Used by host to load agent cards.
    Env AGENT_REGISTRY_PATH overrides; else config host.agent_registry_path; else ROOT/agent_registry.json.
    """
    env_path = os.environ.get("AGENT_REGISTRY_PATH", "").strip()
    if env_path:
        return Path(env_path).resolve()
    c = _load_config().get("host", _DEFAULT_CONFIG["host"])
    raw = c.get("agent_registry_path", "")
    if raw:
        p = Path(raw)
        if not p.is_absolute():
            p = ROOT / p
        return p.resolve()
    return (ROOT / "agent_registry.json").resolve()
