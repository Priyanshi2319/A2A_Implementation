"""
Run the MCP-backed A2A agent. This agent has its own MCP server config via the registry path.
- Registry path: config mcp_agent.registry_path, or MCP_REGISTRY_PATH env, or default mcp_registry.
- MCP server URL is read from that registry (server.json) or MCP_SERVER_URL. Set OPENAI_API_KEY.
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import uvicorn
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCapabilities, AgentCard, AgentSkill
from dotenv import load_dotenv
load_dotenv()

from config_loader import get_mcp_agent_host_port, get_registry_path_for_agent
from portfolio_agent.mcp_agent_executor import MCPAgentExecutor


def main(host: str | None = None, port: int | None = None, registry_path: str | Path | None = None):
    """
    Run the MCP Tool Agent. It uses its own MCP server config from the registry path.
    Registry path: main(registry_path=...) > MCP_REGISTRY_PATH env > config mcp_agent.registry_path > mcp_registry.
    """
    if not os.getenv("OPENAI_API_KEY"):
        raise ValueError("OPENAI_API_KEY environment variable is required")

    cfg_host, cfg_port = get_mcp_agent_host_port("portfolio_agent")
    host = host if host is not None else cfg_host
    port = port if port is not None else cfg_port

    path = registry_path if registry_path is not None else get_registry_path_for_agent("portfolio_agent")
    skill = AgentSkill(
        id="mcp_tools",
        name="MCP tools",
        description="Use remote MCP server tools from the configured registry to answer questions",
        tags=["mcp", "tools", "assistant"],
        examples=["Add 3 and 5", "Greet Alice", "Echo hello world", "generate random number"],
    )

    app_url = os.environ.get("MCP_AGENT_URL", f"http://{host}:{port}")
    agent_card = AgentCard(
        name="MCP Tool Agent",
        description="LangGraph agent that uses tools from its own MCP server (registry path from config or MCP_REGISTRY_PATH).",
        url=app_url,
        version="1.0.0",
        default_input_modes=["text"],
        default_output_modes=["text"],
        capabilities=AgentCapabilities(streaming=True),
        skills=[skill],
    )

    request_handler = DefaultRequestHandler(
        agent_executor=MCPAgentExecutor(registry_path=path),
        task_store=InMemoryTaskStore(),
    )

    app = A2AStarletteApplication(
        agent_card=agent_card,
        http_handler=request_handler,
    )

    uvicorn.run(app.build(), host=host, port=port)


if __name__ == "__main__":
    main()
