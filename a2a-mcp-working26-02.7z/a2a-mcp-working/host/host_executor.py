"""
Host agent executor: handles multiple agents from agent_registry and routes requests
based on agent cards (metadata.agent_id, metadata.skill_id, metadata.skill_tag, or content).
Each registered agent has an AgentCard; resolution picks one agent per request.
"""
import sys
import uuid
from pathlib import Path

# Allow importing from project root (agent_discovery, agent_registry)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx
from a2a.client import A2AClient
from a2a.server.agent_execution import AgentExecutor
from a2a.server.agent_execution.context import RequestContext
from a2a.server.events import EventQueue
from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    Message,
    MessageSendParams,
    SendMessageRequest,
)

import agent_discovery
from agent_discovery import get_agents, resolve_agent_for_request


def _registry_to_agent_card(agent_config: dict) -> AgentCard:
    """Build A2A AgentCard from agent_registry.json entry."""
    skills = []
    for s in agent_config.get("skills", []):
        skills.append(
            AgentSkill(
                id=s.get("id", ""),
                name=s.get("name", ""),
                description=s.get("description", ""),
                tags=s.get("tags", []),
                examples=s.get("examples", []),
            )
        )
    return AgentCard(
        name=agent_config.get("name", "Agent"),
        description=agent_config.get("description", ""),
        url=agent_config.get("url", ""),
        version=agent_config.get("version", "1.0.0"),
        default_input_modes=["text"],
        default_output_modes=["text"],
        capabilities=AgentCapabilities(streaming=True),
        skills=skills or [AgentSkill(id="default", name="Default", description="", tags=[], examples=[])],
    )


class HostAgentExecutor(AgentExecutor):
    """
    Multi-agent executor: routes A2A requests to one of the registered agents.
    Resolution is based on agent cards:
    - metadata.agent_id: use that agent by id
    - metadata.skill_id: use first agent whose card has a skill with that id
    - metadata.skill_tag: use first agent with a skill matching that tag
    - else: content-based or first enabled agent
    """

    def __init__(self, registry_path: str | Path | None = None):
        self._registry_path = registry_path
        self._clients: dict[str, A2AClient] = {}

    def get_available_agent_cards(self) -> list[AgentCard]:
        """Return AgentCards for all enabled agents (for discovery / future multi-agent APIs)."""
        agents = get_agents(self._registry_path)
        return [_registry_to_agent_card(a) for a in agents]

    def _get_client(self, agent_config: dict) -> A2AClient:
        agent_id = agent_config.get("id", "")
        if agent_id not in self._clients:
            card = _registry_to_agent_card(agent_config)
            url = agent_config.get("url", "")
            httpx_client = httpx.AsyncClient(timeout=60.0)
            self._clients[agent_id] = A2AClient(httpx_client, card, url=url)
        return self._clients[agent_id]

    async def execute(
        self,
        context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        meta = context.metadata or {}
        agent_id = meta.get("agent_id")
        skill_id = meta.get("skill_id")
        skill_tag = meta.get("skill_tag")
        user_message = None
        if hasattr(context, "get_user_input"):
            try:
                user_message = context.get_user_input()
            except Exception:
                pass
        if not user_message and getattr(context, "message", None) and getattr(context.message, "parts", None):
            for part in context.message.parts or []:
                if getattr(part, "kind", None) == "text" or (isinstance(part, dict) and part.get("kind") == "text"):
                    text = getattr(part, "text", None) or (part.get("text") if isinstance(part, dict) else None)
                    if text and str(text).strip():
                        user_message = str(text).strip()
                        break

        agent_config = resolve_agent_for_request(
            agent_id=agent_id,
            skill_tag=skill_tag,
            skill_id=skill_id,
            user_message=user_message,
            registry_path=self._registry_path,
        )
        if not agent_config:
            from a2a.utils.message import new_agent_text_message
            await event_queue.enqueue_event(
                new_agent_text_message("No agent available in registry.")
            )
            return

        client = self._get_client(agent_config)
        # Forward a new user message without host task/context ids so the backend creates a new task
        inbound = context.message
        forward_message = Message(
            kind="message",
            messageId=inbound.message_id or str(uuid.uuid4()),
            role=inbound.role,
            parts=inbound.parts,
            taskId=None,
            contextId=None,
            referenceTaskIds=None,
            extensions=inbound.extensions,
            metadata=inbound.metadata,
        )
        params = MessageSendParams(
            message=forward_message,
            configuration=None,
            metadata=context.metadata,
        )
        request = SendMessageRequest(id=str(uuid.uuid4()), method="message/send", params=params)

        try:
            response = await client.send_message(request)
            root = response.root
            if hasattr(root, "result"):
                await event_queue.enqueue_event(root.result)
            else:
                from a2a.utils.message import new_agent_text_message
                await event_queue.enqueue_event(
                    new_agent_text_message(f"Agent error: {getattr(root, 'message', root)}")
                )
        except Exception as e:
            from a2a.utils.message import new_agent_text_message
            await event_queue.enqueue_event(
                new_agent_text_message(f"Host routing error: {e!s}")
            )

    async def cancel(
        self,
        context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        raise NotImplementedError("Cancel not supported")
