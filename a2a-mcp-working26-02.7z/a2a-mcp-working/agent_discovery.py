"""
Agent discovery module: loads agent_registry.json and provides lookup/routing helpers.
"""
import json
import os
from pathlib import Path
from typing import Any

# Default path to registry relative to this file
DEFAULT_REGISTRY_PATH = Path(__file__).parent / "agent_registry.json"


def load_registry(registry_path: str | Path | None = None) -> dict[str, Any]:
    """Load agent registry from JSON file."""
    path = Path(registry_path) if registry_path else DEFAULT_REGISTRY_PATH
    if not path.is_file():
        return {"agents": []}
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def get_agents(registry_path: str | Path | None = None) -> list[dict[str, Any]]:
    """Return list of all registered agents (enabled only by default)."""
    registry = load_registry(registry_path)
    agents = registry.get("agents", [])
    return [a for a in agents if a.get("enabled", True)]


def get_agent_by_id(
    agent_id: str,
    registry_path: str | Path | None = None,
) -> dict[str, Any] | None:
    """Return agent config by id or None if not found."""
    for agent in get_agents(registry_path):
        if agent.get("id") == agent_id:
            return agent
    return None


def get_agent_url(agent_id: str, registry_path: str | Path | None = None) -> str | None:
    """Return agent base URL by id or None."""
    agent = get_agent_by_id(agent_id, registry_path)
    return agent.get("url") if agent else None


def list_agent_ids(registry_path: str | Path | None = None) -> list[str]:
    """Return list of enabled agent ids."""
    return [a["id"] for a in get_agents(registry_path) if a.get("id")]


def _score_agent_for_message(agent: dict[str, Any], user_message: str) -> int:
    """
    Score how well an agent's skills match the user message (0 = no match).
    Uses tags, skill descriptions, and examples from agent_registry skills.
    """
    if not user_message or not user_message.strip():
        return 0
    msg = user_message.strip().lower()
    words = set(msg.split())
    score = 0
    for skill in agent.get("skills", []):
        # Tags: high weight if any tag appears in message or message in tag
        for tag in skill.get("tags", []):
            tag_lower = (tag or "").strip().lower()
            if not tag_lower:
                continue
            if tag_lower in msg or any(tag_lower in w or w in tag_lower for w in words):
                score += 3
        # Description: medium weight
        desc = (skill.get("description") or "").strip().lower()
        if desc and (desc in msg or any(w in desc for w in words if len(w) > 2)):
            score += 2
        # Examples: high weight if message is similar to an example
        for ex in skill.get("examples", []):
            ex_str = (ex if isinstance(ex, str) else str(ex)).strip().lower()
            if not ex_str:
                continue
            if ex_str in msg or msg in ex_str:
                score += 4
            elif words & set(ex_str.split()):
                score += 2
    # Agent description as fallback
    agent_desc = (agent.get("description") or "").strip().lower()
    if agent_desc and (agent_desc in msg or any(w in agent_desc for w in words if len(w) > 2)):
        score += 1
    return score


def resolve_agent_for_request(
    agent_id: str | None = None,
    skill_tag: str | None = None,
    skill_id: str | None = None,
    user_message: str | None = None,
    registry_path: str | Path | None = None,
) -> dict[str, Any] | None:
    """
    Resolve which agent should handle a request based on agent cards / registry.
    - If agent_id is given, return that agent.
    - If skill_id is given, return first agent whose card has a skill with that id.
    - If skill_tag is given, return first agent that has a skill with matching tag.
    - Else: content-based routing using user_message and agent skills (tags, examples, descriptions).
    - If no content match, return first enabled agent as fallback.
    """
    agents = get_agents(registry_path)
    if not agents:
        return None
    if agent_id:
        return get_agent_by_id(agent_id, registry_path)
    if skill_id:
        for agent in agents:
            for skill in agent.get("skills", []):
                if skill.get("id") == skill_id:
                    return agent
    if skill_tag:
        for agent in agents:
            for skill in agent.get("skills", []):
                if skill_tag in skill.get("tags", []):
                    return agent
    # Content-based: score each agent by how well user_message matches its skills
    if user_message and user_message.strip():
        best_agent = None
        best_score = 0
        for agent in agents:
            s = _score_agent_for_message(agent, user_message)
            if s > best_score:
                best_score = s
                best_agent = agent
        if best_agent is not None:
            return best_agent
    return agents[0]
