"""
LLM model factory: returns a LangChain-compatible chat model.
All agent code should use get_llm() from this module so that the LLM provider
can be changed in one place without coupling to a specific provider.
"""
import os
from typing import Any

# Lazy import of the concrete provider to avoid hard dependency at import time
_ChatModel: Any = None


def _get_chat_model():
    """Return the chat model class from the configured provider (e.g. langchain_openai)."""
    global _ChatModel
    if _ChatModel is not None:
        return _ChatModel
    provider = os.getenv("LLM_PROVIDER", "openai").lower()
    if provider == "openai":
        from langchain_openai import ChatOpenAI
        _ChatModel = ChatOpenAI
    else:
        raise ValueError(
            f"Unknown LLM_PROVIDER={provider}. Set LLM_PROVIDER=openai or add support in llm_model.py."
        )
    return _ChatModel


def get_llm(
    *,
    model: str | None = None,
    temperature: float = 0,
    api_key: str | None = None,
    **kwargs: Any,
):
    """
    Return a LangChain-compatible chat model instance.
    Uses config/env for model name and API key so callers stay provider-agnostic.
    """
    model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    api_key = api_key or os.getenv("OPENAI_API_KEY")
    ChatModel = _get_chat_model()
    return ChatModel(
        model=model,
        temperature=temperature,
        api_key=api_key,
        **kwargs,
    )
