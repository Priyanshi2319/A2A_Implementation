def main():
    print("Hello from step-by-step!")


if __name__ == "__main__":
    main()
